export interface VectorizeOptions {
  threshold: number;
  detailStep: number;
  fillColor: string;
  invert: boolean;
  backgroundTransparent: boolean;
}

export const DEFAULT_VECTORIZE_OPTIONS: VectorizeOptions = {
  threshold: 128,
  detailStep: 2,
  fillColor: "#00f0ff",
  invert: false,
  backgroundTransparent: true,
};

/**
 * Traces raster ImageData into an optimized run-length merged SVG string.
 */
export function traceImageDataToSvg(
  imageData: ImageData,
  options: VectorizeOptions = DEFAULT_VECTORIZE_OPTIONS
): { svg: string; pathCount: number } {
  const { width, height, data } = imageData;
  const step = Math.max(1, Math.min(10, Math.round(options.detailStep)));
  const paths: string[] = [];

  for (let y = 0; y < height; y += step) {
    let runStart: number | null = null;

    for (let x = 0; x <= width; x += step) {
      let isActive = false;

      if (x < width) {
        const idx = (y * width + x) * 4;
        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];
        const a = data[idx + 3];

        if (a > 32) {
          const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
          isActive = options.invert
            ? luminance >= options.threshold
            : luminance < options.threshold;
        }
      }

      if (isActive && runStart === null) {
        runStart = x;
      } else if (!isActive && runStart !== null) {
        const runWidth = Math.min(x - runStart, width - runStart);
        const runHeight = Math.min(step, height - y);
        if (runWidth > 0 && runHeight > 0) {
          paths.push(`M${runStart} ${y}h${runWidth}v${runHeight}h-${runWidth}Z`);
        }
        runStart = null;
      }
    }
  }

  const bgRect = options.backgroundTransparent
    ? ""
    : `<rect width="100%" height="100%" fill="#060812"/>`;

  const dAttr = paths.join(" ");
  const svg = [
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">`,
    bgRect,
    dAttr ? `  <path d="${dAttr}" fill="${options.fillColor}" />` : "",
    `</svg>`,
  ]
    .filter(Boolean)
    .join("\n");

  return { svg, pathCount: paths.length };
}

/**
 * Converts SVG markup into Android Vector Drawable XML.
 */
export function convertSvgToAndroidXml(svgMarkup: string): string {
  const parser = new DOMParser();
  const doc = parser.parseFromString(svgMarkup, "image/svg+xml");
  const svgEl = doc.querySelector("svg");

  if (!svgEl) {
    throw new Error("Invalid SVG markup: <svg> root element not found.");
  }

  const viewBox = svgEl.getAttribute("viewBox");
  let viewportWidth = svgEl.getAttribute("width")?.replace(/[^0-9.]/g, "") || "24";
  let viewportHeight = svgEl.getAttribute("height")?.replace(/[^0-9.]/g, "") || "24";

  if (viewBox) {
    const parts = viewBox.trim().split(/[\s,]+/);
    if (parts.length === 4) {
      viewportWidth = parts[2];
      viewportHeight = parts[3];
    }
  }

  const xmlPaths: string[] = [];

  svgEl.querySelectorAll("path").forEach((p) => {
    const d = p.getAttribute("d");
    if (!d) return;
    const fill = normalizeColor(p.getAttribute("fill") || "#FF00F0FF");
    const stroke = p.getAttribute("stroke");
    const strokeWidth = p.getAttribute("stroke-width");

    let attrs = `        android:pathData="${d}"\n        android:fillColor="${fill}"`;
    if (stroke && stroke !== "none") {
      attrs += `\n        android:strokeColor="${normalizeColor(stroke)}"`;
      attrs += `\n        android:strokeWidth="${strokeWidth || "1"}"`;
    }
    xmlPaths.push(`    <path\n${attrs} />`);
  });

  svgEl.querySelectorAll("rect").forEach((r) => {
    const x = parseFloat(r.getAttribute("x") || "0");
    const y = parseFloat(r.getAttribute("y") || "0");
    const w = parseFloat(r.getAttribute("width") || viewportWidth);
    const h = parseFloat(r.getAttribute("height") || viewportHeight);
    const fill = normalizeColor(r.getAttribute("fill") || "#FF00F0FF");
    const d = `M${x},${y} L${x + w},${y} L${x + w},${y + h} L${x},${y + h} Z`;
    xmlPaths.push(
      `    <path\n        android:pathData="${d}"\n        android:fillColor="${fill}" />`
    );
  });

  svgEl.querySelectorAll("circle").forEach((c) => {
    const cx = parseFloat(c.getAttribute("cx") || "0");
    const cy = parseFloat(c.getAttribute("cy") || "0");
    const r = parseFloat(c.getAttribute("r") || "0");
    const fill = normalizeColor(c.getAttribute("fill") || "#FF00F0FF");
    const d = `M ${cx - r}, ${cy} a ${r},${r} 0 1,0 ${r * 2},0 a ${r},${r} 0 1,0 -${r * 2},0`;
    xmlPaths.push(
      `    <path\n        android:pathData="${d}"\n        android:fillColor="${fill}" />`
    );
  });

  if (xmlPaths.length === 0) {
    xmlPaths.push(
      `    <!-- No supported vector shapes (<path>, <rect>, <circle>) detected -->`
    );
  }

  return [
    `<?xml version="1.0" encoding="utf-8"?>`,
    `<vector xmlns:android="http://schemas.android.com/apk/res/android"`,
    `    android:width="${viewportWidth}dp"`,
    `    android:height="${viewportHeight}dp"`,
    `    android:viewportWidth="${viewportWidth}"`,
    `    android:viewportHeight="${viewportHeight}">`,
    ...xmlPaths,
    `</vector>`,
  ].join("\n");
}

function normalizeColor(color: string): string {
  const c = color.trim();
  if (c === "none" || c === "transparent") return "#00000000";
  if (c.startsWith("#")) {
    if (c.length === 4) {
      return `#FF${c[1]}${c[1]}${c[2]}${c[2]}${c[3]}${c[3]}`.toUpperCase();
    }
    return c.toUpperCase();
  }
  return "#FF00F0FF";
}
