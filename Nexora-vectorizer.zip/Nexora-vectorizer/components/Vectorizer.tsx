"use client";

import React, { useState, useRef, useEffect, useCallback } from "react";
import { Upload, Download, Copy, Check, Sliders, RefreshCw } from "lucide-react";
import {
  DEFAULT_VECTORIZE_OPTIONS,
  VectorizeOptions,
  traceImageDataToSvg,
} from "@/lib/vectorize";

export default function Vectorizer() {
  const [options, setOptions] = useState<VectorizeOptions>(DEFAULT_VECTORIZE_OPTIONS);
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [svgOutput, setSvgOutput] = useState<string>("");
  const [pathCount, setPathCount] = useState<number>(0);
  const [copied, setCopied] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);

  const runVectorize = useCallback(() => {
    const img = imgRef.current;
    const canvas = canvasRef.current;
    if (!img || !canvas || !img.complete || img.naturalWidth === 0) return;

    const maxDim = 320;
    const scale = Math.min(1, maxDim / Math.max(img.naturalWidth, img.naturalHeight));
    const w = Math.max(1, Math.round(img.naturalWidth * scale));
    const h = Math.max(1, Math.round(img.naturalHeight * scale));

    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    const imgData = ctx.getImageData(0, 0, w, h);

    const result = traceImageDataToSvg(imgData, options);
    setSvgOutput(result.svg);
    setPathCount(result.pathCount);
  }, [options]);

  useEffect(() => {
    if (imageSrc) {
      runVectorize();
    }
  }, [imageSrc, options, runVectorize]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setImageSrc(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDownloadSvg = () => {
    if (!svgOutput) return;
    const blob = new Blob([svgOutput], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "nexora-vector.svg";
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleCopy = async () => {
    if (!svgOutput) return;
    await navigator.clipboard.writeText(svgOutput);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Controls Sidebar */}
      <div className="lg:col-span-4 rounded-2xl border border-slate-800 bg-[#0d1224]/90 p-6 space-y-6">
        <div className="flex items-center gap-2 text-cyan-400 font-semibold">
          <Sliders className="w-4 h-4" />
          <span>Trace Parameters</span>
        </div>

        <label className="flex flex-col items-center justify-center w-full h-36 border-2 border-dashed border-cyan-500/30 hover:border-cyan-400 rounded-xl bg-slate-950/60 cursor-pointer transition">
          <Upload className="w-6 h-6 text-cyan-400 mb-2" />
          <span className="text-sm font-medium text-slate-200">Upload Raster Image</span>
          <span className="text-xs text-slate-500 mt-1">PNG, JPG, WebP</span>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />
        </label>

        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs text-slate-400 mb-1">
              <span>Luminance Threshold</span>
              <span className="text-cyan-300 font-mono">{options.threshold}</span>
            </div>
            <input
              type="range"
              min={1}
              max={254}
              value={options.threshold}
              onChange={(e) =>
                setOptions({ ...options, threshold: Number(e.target.value) })
              }
              className="w-full accent-cyan-400"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs text-slate-400 mb-1">
              <span>Resolution Step (1 = Finest)</span>
              <span className="text-cyan-300 font-mono">{options.detailStep}px</span>
            </div>
            <input
              type="range"
              min={1}
              max={8}
              value={options.detailStep}
              onChange={(e) =>
                setOptions({ ...options, detailStep: Number(e.target.value) })
              }
              className="w-full accent-cyan-400"
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <label className="text-xs text-slate-400">Vector Fill Color</label>
            <input
              type="color"
              value={options.fillColor}
              onChange={(e) => setOptions({ ...options, fillColor: e.target.value })}
              className="w-9 h-9 rounded cursor-pointer bg-transparent border border-slate-700"
            />
          </div>

          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">Invert Luminance</span>
            <input
              type="checkbox"
              checked={options.invert}
              onChange={(e) => setOptions({ ...options, invert: e.target.checked })}
              className="w-4 h-4 accent-cyan-400"
            />
          </div>

          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">Transparent Background</span>
            <input
              type="checkbox"
              checked={options.backgroundTransparent}
              onChange={(e) =>
                setOptions({ ...options, backgroundTransparent: e.target.checked })
              }
              className="w-4 h-4 accent-cyan-400"
            />
          </div>
        </div>

        <button
          onClick={() => setOptions(DEFAULT_VECTORIZE_OPTIONS)}
          className="w-full py-2 px-3 rounded-lg border border-slate-700 hover:border-slate-600 text-xs text-slate-300 flex items-center justify-center gap-1.5 transition"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Reset Defaults
        </button>
      </div>

      {/* Preview & Output Area */}
      <div className="lg:col-span-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="rounded-2xl border border-slate-800 bg-[#0d1224]/90 p-4 flex flex-col">
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3">
              Original Raster
            </span>
            <div className="flex-1 min-h-[240px] rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-center overflow-hidden p-4">
              {imageSrc ? (
                <img
                  ref={imgRef}
                  src={imageSrc}
                  alt="Uploaded source"
                  onLoad={runVectorize}
                  className="max-h-60 object-contain"
                />
              ) : (
                <p className="text-xs text-slate-500">No image uploaded yet</p>
              )}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-[#0d1224]/90 p-4 flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono uppercase tracking-wider text-cyan-400">
                Vector SVG Preview
              </span>
              {svgOutput && (
                <span className="text-xs font-mono text-slate-400">
                  {pathCount} segments
                </span>
              )}
            </div>
            <div className="flex-1 min-h-[240px] rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-center overflow-hidden p-4">
              {svgOutput ? (
                <div
                  className="max-h-60 w-full flex items-center justify-center [&>svg]:max-h-60 [&>svg]:w-auto"
                  dangerouslySetInnerHTML={{ __html: svgOutput }}
                />
              ) : (
                <p className="text-xs text-slate-500">SVG output will render here</p>
              )}
            </div>
          </div>
        </div>

        <canvas ref={canvasRef} className="hidden" />

        {/* Export Actions */}
        <div className="rounded-2xl border border-slate-800 bg-[#0d1224]/90 p-4 flex flex-wrap items-center justify-between gap-4">
          <div className="text-xs text-slate-400">
            {svgOutput
              ? `Ready to export (${(svgOutput.length / 1024).toFixed(2)} KB)`
              : "Upload an image to generate downloadable SVG code"}
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleCopy}
              disabled={!svgOutput}
              className="px-4 py-2 rounded-lg border border-slate-700 bg-slate-900 hover:border-cyan-500/40 disabled:opacity-40 text-xs font-medium text-slate-200 flex items-center gap-1.5 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? "Copied SVG" : "Copy SVG Code"}
            </button>
            <button
              onClick={handleDownloadSvg}
              disabled={!svgOutput}
              className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-xs font-semibold text-slate-950 flex items-center gap-1.5 transition"
            >
              <Download className="w-3.5 h-3.5" />
              Download .SVG
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
