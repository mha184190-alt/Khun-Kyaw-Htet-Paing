"use client";

import React, { useState } from "react";
import { Activity, Cpu, Database, Save, CheckCircle2 } from "lucide-react";

export default function AdminPanel() {
  const [maxUploadMb, setMaxUploadMb] = useState<number>(15);
  const [defaultPrecision, setDefaultPrecision] = useState<number>(2);
  const [allowBatchXml, setAllowBatchXml] = useState<boolean>(true);
  const [savedToast, setSavedToast] = useState<boolean>(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 2200);
  };

  return (
    <div className="space-y-8">
      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="p-5 rounded-2xl border border-slate-800 bg-[#0d1224]/90 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>TOTAL VECTORIZATIONS</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-2xl font-bold text-white font-mono">12,480</p>
          <p className="text-xs text-emerald-400">+14.2% this week</p>
        </div>

        <div className="p-5 rounded-2xl border border-slate-800 bg-[#0d1224]/90 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>XML COMPILATIONS</span>
            <Database className="w-4 h-4 text-purple-400" />
          </div>
          <p className="text-2xl font-bold text-white font-mono">8,914</p>
          <p className="text-xs text-slate-400">99.8% valid schema rate</p>
        </div>

        <div className="p-5 rounded-2xl border border-slate-800 bg-[#0d1224]/90 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>AVG TRACE LATENCY</span>
            <Cpu className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-bold text-white font-mono">38 ms</p>
          <p className="text-xs text-cyan-400">Client-side WASM/Canvas</p>
        </div>
      </div>

      {/* Engine Configuration Form */}
      <form
        onSubmit={handleSave}
        className="rounded-2xl border border-slate-800 bg-[#0d1224]/90 p-6 space-y-6 max-w-2xl"
      >
        <div>
          <h2 className="text-lg font-semibold text-white">Engine Configuration</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Adjust global defaults for vector tracing and XML serialization.
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs text-slate-300 mb-1.5">
              Max Raster Upload Size (MB)
            </label>
            <input
              type="number"
              min={1}
              max={100}
              value={maxUploadMb}
              onChange={(e) => setMaxUploadMb(Number(e.target.value))}
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3.5 py-2 text-sm text-white focus:border-cyan-500/50 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-300 mb-1.5">
              Default Path Step Precision (1–10)
            </label>
            <input
              type="number"
              min={1}
              max={10}
              value={defaultPrecision}
              onChange={(e) => setDefaultPrecision(Number(e.target.value))}
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3.5 py-2 text-sm text-white focus:border-cyan-500/50 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <div>
              <p className="text-sm text-slate-200 font-medium">
                Enable Android XML Export
              </p>
              <p className="text-xs text-slate-500">
                Allow users to convert SVGs into Vector Drawable XML
              </p>
            </div>
            <input
              type="checkbox"
              checked={allowBatchXml}
              onChange={(e) => setAllowBatchXml(e.target.checked)}
              className="w-4 h-4 accent-purple-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-4 pt-2">
          <button
            type="submit"
            className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-sm font-semibold flex items-center gap-2 transition"
          >
            <Save className="w-4 h-4" />
            Save Settings
          </button>

          {savedToast && (
            <span className="inline-flex items-center gap-1.5 text-xs text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
              Configuration updated
            </span>
          )}
        </div>
      </form>
    </div>
  );
}
