"use client";

import React, { useState } from "react";
import { ArrowRightLeft, Copy, Check, Download, Upload } from "lucide-react";
import { convertSvgToAndroidXml } from "@/lib/vectorize";

const SAMPLE_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path d="M12 2L2 7l10 5 10-5-10-5zm0 7.5L4.5 6 12 2.5 19.5 6 12 9.5zm0 3.5l-10-5v4l10 5 10-5v-4l-10 5zm0 5l-10-5v4l10 5 10-5v-4l-10 5z" fill="#00f0ff"/>
</svg>`;

export default function XmlConverter() {
  const [svgInput, setSvgInput] = useState<string>(SAMPLE_SVG);
  const [xmlOutput, setXmlOutput] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleConvert = () => {
    try {
      setError(null);
      const xml = convertSvgToAndroidXml(svgInput);
      setXmlOutput(xml);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to parse SVG.");
    }
  };

  const handleSvgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setSvgInput(reader.result);
      }
    };
    reader.readAsText(file);
  };

  const handleCopy = async () => {
    if (!xmlOutput) return;
    await navigator.clipboard.writeText(xmlOutput);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const handleDownloadXml = () => {
    if (!xmlOutput) return;
    const blob = new Blob([xmlOutput], { type: "application/xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "ic_nexora_vector.xml";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input SVG */}
        <div className="rounded-2xl border border-slate-800 bg-[#0d1224]/90 p-5 flex flex-col space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase tracking-wider text-cyan-400">
              Input SVG Markup
            </span>
            <label className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg border border-slate-700 hover:border-cyan-500/40 text-xs text-slate-300 cursor-pointer transition">
              <Upload className="w-3.5 h-3.5" />
              Load .SVG
              <input
                type="file"
                accept=".svg,image/svg+xml"
                onChange={handleSvgUpload}
                className="hidden"
              />
            </label>
          </div>

          <textarea
            value={svgInput}
            onChange={(e) => setSvgInput(e.target.value)}
            rows={14}
            placeholder="Paste your <svg>...</svg> code here"
            className="w-full rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500/50 focus:outline-none p-3.5 font-mono text-xs text-slate-200 resize-none"
          />

          <button
            onClick={handleConvert}
            className="w-full py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-sm flex items-center justify-center gap-2 transition"
          >
            <ArrowRightLeft className="w-4 h-4" />
            Convert to Android XML
          </button>
        </div>

        {/* Output XML */}
        <div className="rounded-2xl border border-slate-800 bg-[#0d1224]/90 p-5 flex flex-col space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase tracking-wider text-purple-400">
              Android Vector Drawable (.XML)
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                disabled={!xmlOutput}
                className="px-2.5 py-1 rounded-lg border border-slate-700 hover:border-purple-500/40 disabled:opacity-40 text-xs text-slate-300 flex items-center gap-1 transition"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? "Copied" : "Copy"}
              </button>
              <button
                onClick={handleDownloadXml}
                disabled={!xmlOutput}
                className="px-2.5 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-xs font-medium text-white flex items-center gap-1 transition"
              >
                <Download className="w-3.5 h-3.5" />
                .XML
              </button>
            </div>
          </div>

          {error ? (
            <div className="flex-1 rounded-xl border border-rose-500/40 bg-rose-950/30 p-4 text-xs text-rose-300 font-mono">
              {error}
            </div>
          ) : (
            <textarea
              readOnly
              value={xmlOutput}
              rows={14}
              placeholder="Click 'Convert to Android XML' to generate output..."
              className="w-full rounded-xl bg-slate-950 border border-slate-800 p-3.5 font-mono text-xs text-emerald-300 resize-none focus:outline-none"
            />
          )}
        </div>
      </div>
    </div>
  );
}
