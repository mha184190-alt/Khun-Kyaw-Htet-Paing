"use client";

import React from "react";

export default function CyberBackground() {
  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
      <div className="absolute inset-0 bg-[#060812]" />
      <div
        className="absolute inset-0 bg-cyber-grid bg-[size:44px_44px] opacity-60"
        style={{
          maskImage: "radial-gradient(ellipse at center, black 35%, transparent 80%)",
          WebkitMaskImage: "radial-gradient(ellipse at center, black 35%, transparent 80%)",
        }}
      />
      <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-cyan-500/15 blur-[120px]" />
      <div className="absolute top-1/3 -right-40 w-96 h-96 rounded-full bg-purple-600/15 blur-[130px]" />
    </div>
  );
}
