import React from "react";

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6 flex items-center justify-between border-b border-purple-500/20 pb-4">
        <div>
          <span className="text-xs font-mono uppercase tracking-widest text-purple-400">
            System Administration
          </span>
          <h1 className="text-2xl font-bold text-white">Nexora Admin Workspace</h1>
        </div>
        <span className="px-3 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
          Engine Online
        </span>
      </div>
      {children}
    </div>
  );
}
