import AdminPanel from "@/components/AdminPanel";

export const metadata = {
  title: "Admin Dashboard | Nexora Vectorizer",
};

export default function AdminPage() {
  return <AdminPanel />;
}
