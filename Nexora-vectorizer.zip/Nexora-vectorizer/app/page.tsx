import Link from "next/link";
import { Sparkles, Code2, ShieldCheck, ArrowRight } from "lucide-react";

export default function HomePage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
      <div className="text-center max-w-3xl mx-auto space-y-6">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-cyan-500/30 bg-cyan-500/10 text-cyan-300 text-xs font-medium tracking-wide">
          <Sparkles className="w-3.5 h-3.5" />
          NEXT-GEN VECTOR &amp; XML ENGINE
        </div>

        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white">
          Transform Pixels into{" "}
          <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-purple-400 bg-clip-text text-transparent">
            Scalable Vectors
          </span>
        </h1>

        <p className="text-base sm:text-lg text-slate-400 leading-relaxed">
          Convert PNG/JPG raster graphics into clean SVG paths directly in your browser,
          and instantly compile SVG artwork into production-ready Android Vector Drawable XML.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
          <Link
            href="/vectorizer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold shadow-[0_0_20px_rgba(0,240,255,0.4)] transition"
          >
            Launch Vectorizer
            <ArrowRight className="w-4 h-4" />
          </Link>
          <Link
            href="/xml-converter"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl border border-slate-700 bg-slate-900/70 hover:border-cyan-500/50 text-slate-200 font-semibold transition"
          >
            SVG to XML Converter
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20">
        <Link
          href="/vectorizer"
          className="group p-6 rounded-2xl border border-slate-800 bg-[#0d1224]/80 hover:border-cyan-500/40 transition space-y-3"
        >
          <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition">
            <Sparkles className="w-5 h-5" />
          </div>
          <h2 className="text-lg font-semibold text-white">Image Vectorizer</h2>
          <p className="text-sm text-slate-400">
            Trace raster images with adjustable threshold, color quantization, and path smoothing into crisp SVGs.
          </p>
        </Link>

        <Link
          href="/xml-converter"
          className="group p-6 rounded-2xl border border-slate-800 bg-[#0d1224]/80 hover:border-purple-500/40 transition space-y-3"
        >
          <div className="w-11 h-11 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 group-hover:scale-105 transition">
            <Code2 className="w-5 h-5" />
          </div>
          <h2 className="text-lg font-semibold text-white">Android XML Converter</h2>
          <p className="text-sm text-slate-400">
            Parse SVG geometry, viewBox dimensions, and fill attributes into ready-to-use Android Vector Drawable XML.
          </p>
        </Link>

        <Link
          href="/admin"
          className="group p-6 rounded-2xl border border-slate-800 bg-[#0d1224]/80 hover:border-emerald-500/40 transition space-y-3"
        >
          <div className="w-11 h-11 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h2 className="text-lg font-semibold text-white">Admin Control Deck</h2>
          <p className="text-sm text-slate-400">
            Configure default vectorization presets, monitor conversion jobs, and manage system parameters.
          </p>
        </Link>
      </div>
    </div>
  );
}
