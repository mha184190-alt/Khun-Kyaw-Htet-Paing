import type { Metadata } from "next";
import Link from "next/link";
import CyberBackground from "@/components/CyberBackground";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nexora Vectorizer | Raster to SVG & XML Studio",
  description: "Convert raster images to crisp SVG vectors and transform SVG paths into clean Android Vector Drawable XML.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col antialiased selection:bg-cyan-500/30 selection:text-cyan-200">
        <CyberBackground />

        <header className="sticky top-0 z-40 border-b border-cyan-500/20 bg-[#060812]/80 backdrop-blur-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2.5 group">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-purple-600 flex items-center justify-center shadow-[0_0_15px_rgba(0,240,255,0.4)] group-hover:shadow-[0_0_25px_rgba(0,240,255,0.7)] transition">
                <span className="font-bold text-slate-950 text-lg">N</span>
              </div>
              <span className="font-bold text-lg tracking-wider bg-gradient-to-r from-cyan-300 via-white to-purple-300 bg-clip-text text-transparent">
                NEXORA<span className="font-light text-cyan-400">.VEC</span>
              </span>
            </Link>

            <nav className="flex items-center gap-1 sm:gap-4 text-sm font-medium">
              <Link
                href="/vectorizer"
                className="px-3 py-1.5 rounded-lg text-slate-300 hover:text-cyan-300 hover:bg-cyan-500/10 transition"
              >
                Vectorizer
              </Link>
              <Link
                href="/xml-converter"
                className="px-3 py-1.5 rounded-lg text-slate-300 hover:text-cyan-300 hover:bg-cyan-500/10 transition"
              >
                XML Converter
              </Link>
              <Link
                href="/admin"
                className="px-3 py-1.5 rounded-lg text-purple-300 border border-purple-500/30 hover:bg-purple-500/15 transition"
              >
                Admin
              </Link>
            </nav>
          </div>
        </header>

        <main className="flex-1 relative z-10">{children}</main>

        <footer className="relative z-10 border-t border-slate-800/80 bg-[#060812]/90 py-6 text-center text-xs text-slate-500">
          <p>Nexora Vectorizer Suite &copy; {new Date().getFullYear()} &mdash; Precision Vector &amp; XML Tooling</p>
        </footer>
      </body>
    </html>
  );
}
