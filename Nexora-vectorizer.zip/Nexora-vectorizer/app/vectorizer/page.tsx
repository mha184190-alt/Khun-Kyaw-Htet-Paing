import Vectorizer from "@/components/Vectorizer";

export const metadata = {
  title: "Image Vectorizer | Nexora Vectorizer",
};

export default function VectorizerPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white">Raster to SVG Vectorizer</h1>
        <p className="text-sm text-slate-400 mt-1">
          Upload any PNG, JPG, or WebP image to trace crisp vector paths in real time.
        </p>
      </div>
      <Vectorizer />
    </div>
  );
}
