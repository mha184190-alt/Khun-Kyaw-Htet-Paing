import XmlConverter from "@/components/XmlConverter";

export const metadata = {
  title: "SVG to XML Converter | Nexora Vectorizer",
};

export default function XmlConverterPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white">SVG to Android Vector XML</h1>
        <p className="text-sm text-slate-400 mt-1">
          Paste or upload SVG markup to generate clean Android Vector Drawable XML.
        </p>
      </div>
      <XmlConverter />
    </div>
  );
}
